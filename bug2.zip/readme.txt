If you call send_raw_message(dest_wallet,0, 128) with mode = 128 and then call send_raw_message (s_addr,0, 64) with mode = 64, the transaction will end with error code 37 and will be canceled. Since the transaction was canceled, the funds were not transferred to dest_wallet (see source code - test_bug.fc), however, the grams that came with the message were successfully credited to the smart contract account. In theory, if the transaction was canceled, then the grams that come with the message should return to the sender’s wallet, but this did not happen. Further, the oddities continued. The smart contract balance began to melt and decreased to a certain value. Moreover, the balance of the sender remained unchanged.

To replay this bug:
1. Run the test2-upload.fif script. It will create a test-bug-query.boc file and show the address of the smart contract. Make sure that the smart contract is not yet loaded at this address, if it is already loaded, change the line "throw_if (58, is_init);" number 58 to any other so that the script creates a new address.
2. Send 1 gram to the smart contract initialization address.
3. Send the .boc file via lite-client to TON (sendfile <path> test-bug-query.boc)
4. When the smart contract is downloaded, send 1 gram to it from any wallet.
5. The transaction will end with code 37, but 1 gram will be credited to the smart contract account.
6. From this moment, the balance of the smart contract will melt to a certain value, then it will stop.
Just check if everything is normal there. Maybe this is part of another bug.

Smart contract which I uploaded for test - kQAn1Y6bg6zPQTtq4ScdX52JPIpqdNVBvR-9jHAwSC8uzKEr
Strange transaction with result code 37 - https://test.ton.org/testnet/transaction?account=kQAn1Y6bg6zPQTtq4ScdX52JPIpqdNVBvR-9jHAwSC8uzKEr&lt=1393967000001&hash=0BDC4091FCE27F6ECA0CAB7CBB241432F3319335B6727742298F8940B7426158

